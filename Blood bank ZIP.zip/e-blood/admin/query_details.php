<?php
include 'conn.php';  // Include database connection
include 'session.php';  // Include session handling

// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    // Check if 'id' is passed in the URL
    if (isset($_GET['id'])) {
        $que_id = $_GET['id'];

        // SQL query to fetch the query details based on query_id
        $sql = "SELECT * FROM contact_query WHERE query_id = $que_id";
        $result = mysqli_query($conn, $sql);

        // Check if the query returned any result
        if (mysqli_num_rows($result) > 0) {
            // Fetch the query details from the result
            $row = mysqli_fetch_assoc($result);
            ?>

            <div class="container">
                <h1>User Query Details</h1>

                <p><strong>Name:</strong> <?php echo $row['query_name']; ?></p>
                <p><strong>Email:</strong> <?php echo $row['query_mail']; ?></p>
                <p><strong>Mobile Number:</strong> <?php echo $row['query_number']; ?></p>
                <p><strong>Message:</strong> <?php echo $row['query_message']; ?></p>
                <p><strong>Posting Date:</strong> <?php echo $row['query_date']; ?></p>
                <p><strong>Status:</strong> 
                    <?php 
                    if ($row['query_status'] == 1) {
                        echo 'Read';
                    } else {
                        echo 'Pending';
                    }
                    ?>
                </p>
            </div>

            <?php
        } else {
            // If no query is found for the provided query_id
            echo '<div class="alert alert-danger">No query found with this ID.</div>';
        }
    } else {
        // If 'id' is not set in the URL
        echo '<div class="alert alert-danger">Invalid query ID.</div>';
    }
} else {
    // If the user is not logged in
    echo '<div class="alert alert-danger">Please log in to access the admin portal.</div>';
}

mysqli_close($conn);  // Close the database connection
?>
