<?php
include 'conn.php'; // Include database connection
include 'session.php'; // Include session handling

// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    if (isset($_GET['id'])) {
        $que_id = $_GET['id'];

        // SQL query to delete the specific query
        $sql = "DELETE FROM contact_query WHERE query_id = $que_id";

        if (mysqli_query($conn, $sql)) {
            // Query successfully deleted
            echo '<div class="alert alert-success">Query deleted successfully.</div>';
            // Redirect to the queries page after 2 seconds
            header("refresh:2;url=query.php");
        } else {
            // Error deleting the query
            echo '<div class="alert alert-danger">Error deleting query: ' . mysqli_error($conn) . '</div>';
        }
    } else {
        // If no query ID is provided
        echo '<div class="alert alert-danger">Invalid query ID.</div>';
    }
} else {
    // If the user is not logged in
    echo '<div class="alert alert-danger">Please log in to access the admin portal.</div>';
}
mysqli_close($conn); // Close the database connection
?>
