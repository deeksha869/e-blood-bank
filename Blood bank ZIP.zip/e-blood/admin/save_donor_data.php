<?php
// Get the data from the form
$name = $_POST['fullname'];
$number = $_POST['mobileno'];
$email = $_POST['emailid'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$blood_group = $_POST['blood'];
$address = $_POST['address'];

// Create a connection to the database
$conn = mysqli_connect("localhost", "root", "Pa@11081981", "blood_donation") or die("Connection failed: " . mysqli_connect_error());

// Prepare and execute the SQL query to insert the donor data
$sql = "INSERT INTO donor_details (donor_name, donor_number, donor_mail, donor_age, donor_gender, donor_blood, donor_address) 
        VALUES ('{$name}', '{$number}', '{$email}', '{$age}', '{$gender}', '{$blood_group}', '{$address}')";

$result = mysqli_query($conn, $sql);

// Check if the insertion was successful and handle the result
if ($result) {
    // Redirect to the donor list page if the insertion is successful
    header("Location: donor_list.php"); // Using relative path for redirection
    exit(); // Always use exit after header redirection
} else {
    // Display an error message if the query fails
    die("Query unsuccessful: " . mysqli_error($conn));
}

// Close the database connection
mysqli_close($conn);
?>
