<?php
$conn=mysqli_connect("localhost","root","Pa@11081981","blood_donation") or die("Connection error");
?>
